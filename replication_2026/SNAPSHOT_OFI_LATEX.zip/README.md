# LaTeX source package

Main file: SNAPSHOT_OFI_PAPER.tex. Compile with Tectonic, or compile twice with a standard LaTeX installation. Upload this ZIP to Overleaf and select that main file. Tables, bibliography and vector plot are embedded; no other source files are needed.

The compiled paper is a nine-page research draft pending final coauthor approval. The release audit corrected the forward current-return filter without changing the primary measurement results or rounded five-minute conclusions. Full documentation: https://github.com/brendanconnelly/snapshot-ofi-paper (initially private); shared research record: https://github.com/RM1505/math279_project/tree/research/ofi-snapshot-study-2026.
