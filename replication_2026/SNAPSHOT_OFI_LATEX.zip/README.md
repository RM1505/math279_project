# Snapshot OFI paper — 24 October 2026

Main file: SNAPSHOT_OFI_PAPER.tex. Compile with Tectonic, or compile twice with a standard LaTeX installation. Upload this ZIP to Overleaf and select that main file. All tables and references are embedded. No external images or bibliography files are needed.

This nine-page research draft includes the ranking, reconstruction and bounded generalized-OFI extension. It remains pending coauthor review and does not claim event-level validation or established novelty. Documentation, code and compact results: https://github.com/brendanconnelly/snapshot-ofi-paper (private; access required). Shared research history: https://github.com/RM1505/math279_project/tree/research/ofi-snapshot-study-2026.
